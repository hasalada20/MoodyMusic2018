# MoodyMusic2018
A project in Dr. Moorman's Software Engineering class
we're going to do things
We will definitely try